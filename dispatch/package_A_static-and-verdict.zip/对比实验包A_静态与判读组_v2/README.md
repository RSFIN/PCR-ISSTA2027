# 对比实验包 v2 —— 从这里开始

> 生成：2026-11-06 ｜ 语料：**96 条**变更单 ｜ 待判用例：**522 个**（正负混排，不标标签）
> 你的任务书是同目录的 `任务书.md`，**先读它**；标契约之前读 `人工标注口径与判断依据.md`。

## 30 秒跑通

```bash
# 1) 环境自检：应输出 522
python -c "from lib.common import load_cases; print(len(load_cases()))"

# 2) 跑模板（永远返回 UNDETERMINED，只为验证管线）
python baselines/template/run.py --limit 5

# 3) 看汇总
python baselines/collect.py
```

## 目录

```
inputs/
  cases.tsv           522 个用例索引（case_id / name），顺序固定 seed 混排
  cases/c0001.st…     522 个待判补丁（统一命名，看不出正负）
  orig/<name>.st      96 个原程序
  specs/<name>.json   96 张变更单（order / n / origin）——**没有契约、没有 kind**
  manifest.tsv        条目清单（周期数 / 输出个数 / 来源）
  annot/cards/        标注卡：变更单 + 原程序（标契约只读这个）
  annot/A1_allow.tsv  静态组的 allow 表（空表，96 行）
  annot/B1_contract.tsv 执行组的人工契约表（空表，96 行）
  l6/L6_盲测表.tsv    人类基线 30 条（空表）
lib/                  共用执行语义（engine / stlang / common）
baselines/template/   复制这个目录开始写你的配置
docs/                 背景文档
```

## 三条硬规矩

1. **判不了就 `UNDETERMINED`**，不折算、不猜。
2. **标契约时只看 `annot/cards/`**，不许先看 `cases/`——否则等于抄答案。
3. **不许改 `lib/`**，也不许根据编号/顺序推断正负。
