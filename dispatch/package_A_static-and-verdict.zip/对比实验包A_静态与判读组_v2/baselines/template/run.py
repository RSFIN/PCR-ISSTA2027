#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""配置模板 —— 复制这个目录，改名，实现 judge() 即可。

    cp -r baselines/template baselines/c2_sdg
    # 编辑 baselines/c2_sdg/run.py，把 cli("template", ...) 改成 cli("c2_sdg", ...)
    python baselines/c2_sdg/run.py --limit 5     # 先冒烟
    python baselines/c2_sdg/run.py               # 再全量

judge(case) 返回 (verdict, reason, evidence)：
    verdict  ∈ {"VIOLATED", "CONTAINED", "UNDETERMINED"}   —— 只能是这三个
    reason   一句话说明为什么（会进论文的错误分析，请认真写）
    evidence 可选：反例轨迹 / 行号 / 变量名，便于复核

**重要**：判不了就返回 UNDETERMINED，不要猜。猜出来的数字会把整张表带偏。
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
from lib.common import cli, diff_lines  # noqa: E402


def judge(case):
    """把这里换成你的方法。下面只是把改动打出来，永远返回 UNDETERMINED。"""
    changed = [l for tag, l in diff_lines(case.orig, case.patch) if tag in "+-"]
    return ("UNDETERMINED",
            f"模板未实现；本条改动 {len(changed)} 行",
            "order: " + case.spec.get("order", "")[:80])


if __name__ == "__main__":
    cli("template", judge)
