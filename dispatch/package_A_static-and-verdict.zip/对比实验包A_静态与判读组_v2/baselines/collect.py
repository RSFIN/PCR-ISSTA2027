#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""汇总所有配置的结果成一张表 + 一致性检查。

用法：
    python baselines/collect.py
    python baselines/collect.py --check     # 只做完整性检查

做三件事：
1. 把 baselines/*/results.jsonl 合成 baselines/results.csv
2. 检查每个配置是否跑满 295 个用例、verdict 是否合法、有无重复
3. 打印一张「配置 × 三值分布 × 平均耗时」的表

注意：这里**不算** recall/FPR —— 标签在负责人手上，由他统一算，
避免各自口径不一致（也避免有人照着标签调参）。
"""
import glob
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
VERDICTS = ("VIOLATED", "CONTAINED", "UNDETERMINED")


def expected_cids():
    out = []
    for line in open(os.path.join(ROOT, "inputs", "cases.tsv"), encoding="utf-8"):
        if line.strip() and not line.startswith("#"):
            out.append(line.split("\t")[0])
    return out


def main():
    want = expected_cids()
    rows, problems = [], []
    for d in sorted(glob.glob(os.path.join(HERE, "*"))):
        f = os.path.join(d, "results.jsonl")
        if not os.path.isfile(f):
            continue
        config = os.path.basename(d)
        got = {}
        for line in open(f, encoding="utf-8"):
            if not line.strip():
                continue
            r = json.loads(line)
            if r["cid"] in got:
                problems.append(f"{config}: 重复的 {r['cid']}")
            got[r["cid"]] = r
            rows.append(r)
        missing = [c for c in want if c not in got]
        extra = [c for c in got if c not in want]
        if missing:
            problems.append(f"{config}: 缺 {len(missing)} 个用例（如 {missing[:3]}）")
        if extra:
            problems.append(f"{config}: 多出 {len(extra)} 个不存在的用例（如 {extra[:3]}）")
        bad = [r["cid"] for r in got.values() if r["verdict"] not in VERDICTS]
        if bad:
            problems.append(f"{config}: verdict 非法 {len(bad)} 个（如 {bad[:3]}）")

    if rows:
        csv = os.path.join(HERE, "results.csv")
        cols = ["cid", "name", "config", "verdict", "reason", "evidence", "time_s", "model"]
        with open(csv, "w", encoding="utf-8") as fh:
            fh.write(",".join(cols) + "\n")
            for r in rows:
                fh.write(",".join('"' + str(r.get(c, "")).replace('"', "'") + '"'
                                  for c in cols) + "\n")
        print(f"-> {csv}（{len(rows)} 行）\n")

    print(f"{'config':22s} {'n':>5s} {'VIOLATED':>9s} {'CONTAINED':>10s} "
          f"{'UNDET':>7s} {'ms/个':>7s}")
    print("-" * 66)
    for d in sorted(glob.glob(os.path.join(HERE, "*"))):
        f = os.path.join(d, "results.jsonl")
        if not os.path.isfile(f):
            continue
        rs = [json.loads(l) for l in open(f, encoding="utf-8") if l.strip()]
        if not rs:
            continue
        n = len(rs)
        ms = sum(r.get("time_s", 0) for r in rs) / n * 1000
        c = {v: sum(1 for r in rs if r["verdict"] == v) for v in VERDICTS}
        print(f"{os.path.basename(d):22s} {n:5d} {c['VIOLATED']:4d} "
              f"({c['VIOLATED']/n:4.0%}) {c['CONTAINED']:5d} ({c['CONTAINED']/n:4.0%}) "
              f"{c['UNDETERMINED']:4d} ({c['UNDETERMINED']/n:3.0%}) {ms:7.0f}")

    print()
    if problems:
        print(f"⚠️  {len(problems)} 个问题：")
        for p in problems:
            print("   -", p)
        return 1
    print("✅ 所有配置完整、verdict 合法、无重复")
    return 0


if __name__ == "__main__":
    sys.exit(main())
