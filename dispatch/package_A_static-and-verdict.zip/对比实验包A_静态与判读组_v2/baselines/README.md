# baselines —— 怎么加一个对比配置

每个配置 = `baselines/` 下的一个目录，里面一个 `run.py`，只实现 `judge()`。

```
baselines/
  template/run.py        # 复制这个开始
  c2_sdg/run.py          # 你的配置
  c2_sdg/results.jsonl   # 跑出来的结果（自动生成）
  results.csv            # 汇总（自动生成）
```

## 三步

```bash
cp -r baselines/template baselines/c2_sdg
# 编辑 baselines/c2_sdg/run.py：实现 judge()，把 cli("template",...) 改成 cli("c2_sdg",...)
python baselines/c2_sdg/run.py --limit 5    # 冒烟
python baselines/c2_sdg/run.py             # 全量 295 个
```

## judge(case) 的输入

| 字段 | 内容 |
|-|-|
| `case.cid` | 用例编号（`c0001`…） |
| `case.name` | 条目名（如 `gate_hold_1s`），同一程序的多个用例 `name` 相同 |
| `case.orig` | **原程序**全文（ST） |
| `case.patch` | **待判补丁**全文（ST） |
| `case.spec` | 变更单：`order`（自然语言）、`kind`、`n`（周期数）、`provenance` |

## 返回值

```python
return ("VIOLATED", "一句话为什么", "可选证据：轨迹/行号/变量名")
```

- 三个值只能是 `VIOLATED` / `CONTAINED` / `UNDETERMINED`
- **判不了就返回 `UNDETERMINED`**，不要猜。猜出来的数字会污染整张对比表，比返回空更糟
- `reason` 会用于论文的错误分析，请写具体（"第三条赋值越出 allow"比"不通过"有用得多）

## 工具

`lib.common` 里提供：

```python
from lib.common import diff_lines
diff_lines(orig, patch)   # -> [('-', 旧行), ('+', 新行), ('@@', ...)]
```

`lib/engine.py` 是逐周期执行器（`engine.run(...)`），`lib/stlang.py` 是 ST 解析器。
**这两个是共用的，不要改**。需要改先提 issue，因为所有人的结果都要用同一个语义。

## 自检

```bash
python baselines/collect.py --check
```

会检查：是否跑满 295 个、verdict 是否合法、有无重复/缺项。**交之前必须过这一关。**

## 关于标签

包里**没有**标签，正负例混排、编号固定但随机。这是故意的：避免照着答案调参。
`collect.py` 也不算 recall/FPR——由负责人用统一口径算，保证所有配置同一把尺。
