# conc_stage2

**变更单**：可燃气体二级报警阈值由 70 改为 60；其余逻辑不变。

**周期数**：300 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_ConcAlarm
VAR_INPUT
    rConc    : REAL;
    xPurgeEn : BOOL;
END_VAR
VAR_OUTPUT
    yAlarm1 : BOOL;
    yAlarm2 : BOOL;
    yPurge  : BOOL;
END_VAR
    yAlarm1 := rConc > 40;
    yAlarm2 := rConc > 70;
    yPurge  := yAlarm2 AND xPurgeEn;
END_FUNCTION_BLOCK
```
