# heat_zone1_manual

**变更单**：手动模式下允许第一段加热输出，不再受手动闭锁限制；其余逻辑不变。

**周期数**：700 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_HeatZone
VAR_INPUT
    xAuto   : BOOL;
    xManual : BOOL;
    iTemp   : INT;
END_VAR
VAR_OUTPUT
    yHeat1    : BOOL;
    yHeat2    : BOOL;
    yOverTemp : BOOL;
END_VAR
    yHeat1    := xAuto AND NOT xManual;
    yHeat2    := xAuto;
    yOverTemp := iTemp >= 80 AND NOT xManual;
END_FUNCTION_BLOCK
```
