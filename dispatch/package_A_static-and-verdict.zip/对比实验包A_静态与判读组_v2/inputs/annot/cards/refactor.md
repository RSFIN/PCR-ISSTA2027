# refactor

**变更单**：把 R_TRIG 边沿检测改为显式上升沿判断，行为必须逐周期不变。

**周期数**：900 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_Gate
VAR_INPUT
    xPart : BOOL;
END_VAR
VAR_OUTPUT
    yGate : BOOL;
END_VAR
VAR
    rtPart  : R_TRIG;
    tonHold : TON;
END_VAR
    rtPart(CLK := xPart);
    IF rtPart.Q THEN
        yGate := TRUE;
    END_IF;
    tonHold(IN := yGate, PT := T#500MS);
    IF tonHold.Q THEN
        yGate := FALSE;
    END_IF;
END_FUNCTION_BLOCK
```
