# guard_clean_brush_water

**变更单**：xWater 断开时，该联锁不再约束手动支路，手动模式下允许刷盘转动；xWater 断开这一前提不变，窗口外维持原闭锁；其余逻辑不变。

**周期数**：700 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_CleanCell
VAR_INPUT
    xAuto      : BOOL;
    xManual    : BOOL;
    xWater     : BOOL;
    xPermit    : BOOL;
END_VAR
VAR_OUTPUT
    yPump     : BOOL;
    yDry      : BOOL;
    yBrush    : BOOL;
    yAlarm    : BOOL;
END_VAR
    yPump := xAuto AND xPermit AND xWater AND NOT xManual;
    yDry := xAuto AND xPermit AND xWater AND NOT xManual;
    yBrush := xAuto AND xPermit AND xWater;
    yAlarm := NOT xWater;
END_FUNCTION_BLOCK
```
