# standby_fault_a

**变更单**：故障时允许主泵继续运行，故障闭锁只约束备用泵；其余逻辑不变。

**周期数**：700 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_PumpStandby
VAR_INPUT
    xAuto   : BOOL;
    xManual : BOOL;
    xFault  : BOOL;
END_VAR
VAR_OUTPUT
    yPumpA     : BOOL;
    yPumpB     : BOOL;
    ySwapAlarm : BOOL;
    yLamp      : BOOL;
END_VAR
    yPumpA     := xAuto AND NOT xFault AND NOT xManual;
    yPumpB     := xAuto AND xFault;
    ySwapAlarm := xFault AND NOT xManual;
    yLamp      := xAuto;
END_FUNCTION_BLOCK
```
