# stardelta

**变更单**：星三角切换延时由 5 秒改为 7 秒；其余逻辑不变。

**周期数**：1000 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_StarDelta
VAR_INPUT
    xStart    : BOOL;
    xStop     : BOOL;
    xOverload : BOOL;
END_VAR
VAR_OUTPUT
    yMain  : BOOL;
    yStar  : BOOL;
    yDelta : BOOL;
    yFault : BOOL;
END_VAR
VAR
    tonTrans : TON;
END_VAR
    yMain := xStart AND NOT xStop AND NOT xOverload;
    tonTrans(IN := yMain, PT := T#5S);
    yStar  := yMain AND NOT tonTrans.Q;
    yDelta := yMain AND tonTrans.Q;
    yFault := xOverload;
END_FUNCTION_BLOCK
```
