# tank_low_stop

**变更单**：液位罐低液位停泵阈值由 10 改为 20；其余逻辑不变。

**周期数**：300 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_Tank
VAR_INPUT
    iLevel : INT;
    xReset : BOOL;
END_VAR
VAR_OUTPUT
    yPump  : BOOL;
    yAlarm : BOOL;
END_VAR
    IF iLevel <= 10 THEN
        yPump  := FALSE;
        yAlarm := TRUE;
    ELSIF iLevel >= 90 THEN
        yPump  := FALSE;
        yAlarm := FALSE;
    ELSE
        yPump  := TRUE;
        yAlarm := FALSE;
    END_IF;
END_FUNCTION_BLOCK
```
