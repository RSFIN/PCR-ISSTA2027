# enable_lamp_manual

**变更单**：手动模式下允许运行指示输出，不再受手动闭锁限制；其余逻辑不变。

**周期数**：700 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_EnableChain
VAR_INPUT
    xStart  : BOOL;
    xAuto   : BOOL;
    xManual : BOOL;
END_VAR
VAR_OUTPUT
    yHeat : BOOL;
    yFan  : BOOL;
    yLamp : BOOL;
END_VAR
    yHeat := xStart AND NOT xManual;
    yFan  := xStart;
    yLamp := xStart AND NOT xManual AND NOT xAuto;
END_FUNCTION_BLOCK
```
