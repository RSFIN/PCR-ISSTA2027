# level3_low

**变更单**：液位三段控制的低段切换阈值由 30 改为 40；其余逻辑不变。

**周期数**：300 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_Level3
VAR_INPUT
    rLevel : REAL;
END_VAR
VAR_OUTPUT
    yFill  : BOOL;
    yHold  : BOOL;
    yDrain : BOOL;
END_VAR
    IF rLevel < 30 THEN
        yFill  := TRUE;
        yHold  := FALSE;
        yDrain := FALSE;
    ELSIF rLevel > 70 THEN
        yFill  := FALSE;
        yHold  := FALSE;
        yDrain := TRUE;
    ELSE
        yFill  := FALSE;
        yHold  := TRUE;
        yDrain := FALSE;
    END_IF;
END_FUNCTION_BLOCK
```
