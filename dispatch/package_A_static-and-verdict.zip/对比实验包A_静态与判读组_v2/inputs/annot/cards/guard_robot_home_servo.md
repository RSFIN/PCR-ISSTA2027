# guard_robot_home_servo

**变更单**：xServo 断开时，该联锁不再约束手动支路，手动模式下允许回原点动作；xServo 断开这一前提不变，窗口外维持原闭锁；其余逻辑不变。

**周期数**：700 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_RobotCell
VAR_INPUT
    xAuto      : BOOL;
    xManual    : BOOL;
    xServo     : BOOL;
    xPermit    : BOOL;
END_VAR
VAR_OUTPUT
    yWeld     : BOOL;
    yMove     : BOOL;
    yHome     : BOOL;
    yAlarm    : BOOL;
END_VAR
    yWeld := xAuto AND xPermit AND xServo AND NOT xManual;
    yMove := xAuto AND xPermit AND xServo AND NOT xManual;
    yHome := xAuto AND xPermit AND xServo;
    yAlarm := NOT xServo;
END_FUNCTION_BLOCK
```
