# guard_valve_a_manual

**变更单**：xPermit 断开时，该联锁不再约束手动支路，手动模式下允许进料阀 A 动作；xPermit 断开这一前提不变，窗口外维持原闭锁；其余逻辑不变。

**周期数**：700 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_ValveBank
VAR_INPUT
    xAuto      : BOOL;
    xManual    : BOOL;
    xPermit    : BOOL;
    xReady     : BOOL;
END_VAR
VAR_OUTPUT
    yValveA    : BOOL;
    yValveB    : BOOL;
    yValveC    : BOOL;
    yAlarm     : BOOL;
END_VAR
    yValveA := xAuto AND xPermit AND xReady AND NOT xManual;
    yValveB := xAuto AND xPermit AND xReady AND NOT xManual;
    yValveC := xAuto AND xPermit AND xReady;
    yAlarm := NOT xPermit;
END_FUNCTION_BLOCK
```
