# interlock_clamp_overload

**变更单**：过载时允许手动夹紧，过载闭锁只约束自动模式；其余逻辑不变。

**周期数**：700 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_InterlockMatrix
VAR_INPUT
    xAuto     : BOOL;
    xManual   : BOOL;
    xReady    : BOOL;
    xOverload : BOOL;
END_VAR
VAR_OUTPUT
    yClamp : BOOL;
    yPress : BOOL;
    yEject : BOOL;
    yAlarm : BOOL;
END_VAR
    yClamp := xAuto AND xReady AND NOT xOverload AND NOT xManual;
    yPress := xAuto AND xReady AND NOT xOverload AND NOT xManual;
    yEject := xAuto AND xReady;
    yAlarm := NOT xOverload;
END_FUNCTION_BLOCK
```
