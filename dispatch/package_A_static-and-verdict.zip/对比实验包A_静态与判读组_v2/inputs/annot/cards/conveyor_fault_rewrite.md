# conveyor_fault_rewrite

**变更单**：把故障输出的复合条件改写为等价的顺序判断，行为必须逐周期不变；其余逻辑不变。

**周期数**：900 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_Conveyor
VAR_INPUT
    xStart    : BOOL;
    xStop     : BOOL;
    xEStop    : BOOL;
    xOverload : BOOL;
END_VAR
VAR_OUTPUT
    yRun   : BOOL;
    yFault : BOOL;
END_VAR
VAR
    tonDb : TON;
    xPerm : BOOL;
END_VAR
    tonDb(IN := xStart AND NOT xStop, PT := T#200MS);
    xPerm := tonDb.Q AND NOT xEStop AND NOT xOverload;
    yRun  := xPerm;
    yFault := xOverload OR xEStop;
END_FUNCTION_BLOCK
```
