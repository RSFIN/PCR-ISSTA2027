# vfd_low

**变更单**：变频器频率下限阈值由 20 改为 30；其余逻辑不变。

**周期数**：300 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_VfdLimit
VAR_INPUT
    rFreq : REAL;
    xRun  : BOOL;
END_VAR
VAR_OUTPUT
    yClamp : BOOL;
    yMotor : BOOL;
END_VAR
    IF rFreq < 20 THEN
        yClamp := TRUE;
    ELSIF rFreq > 50 THEN
        yClamp := TRUE;
    ELSE
        yClamp := FALSE;
    END_IF;
    IF xRun AND NOT yClamp THEN
        yMotor := TRUE;
    END_IF;
    IF yClamp THEN
        yMotor := FALSE;
    END_IF;
END_FUNCTION_BLOCK
```
