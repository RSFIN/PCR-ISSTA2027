# hyst_connect

**变更单**：滞环比较器的接通阈值由 20 改为 30；其余逻辑不变。

**周期数**：300 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_Hyst
VAR_INPUT
    rIn : REAL;
END_VAR
VAR_OUTPUT
    yQ   : BOOL;
    yWin : BOOL;
END_VAR
    IF rIn < 20 THEN
        yQ   := FALSE;
        yWin := FALSE;
    ELSIF rIn > 80 THEN
        yQ   := TRUE;
        yWin := FALSE;
    ELSE
        yWin := TRUE;
    END_IF;
END_FUNCTION_BLOCK
```
