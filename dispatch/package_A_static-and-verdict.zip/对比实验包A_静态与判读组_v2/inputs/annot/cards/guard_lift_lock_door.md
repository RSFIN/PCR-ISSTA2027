# guard_lift_lock_door

**变更单**：xDoor 断开时，该联锁不再约束手动支路，手动模式下允许锁紧销伸出；xDoor 断开这一前提不变，窗口外维持原闭锁；其余逻辑不变。

**周期数**：700 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_LiftLock
VAR_INPUT
    xAuto      : BOOL;
    xManual    : BOOL;
    xDoor      : BOOL;
    xPermit    : BOOL;
END_VAR
VAR_OUTPUT
    yUp       : BOOL;
    yDown     : BOOL;
    yLock     : BOOL;
    yAlarm    : BOOL;
END_VAR
    yUp := xAuto AND xPermit AND xDoor AND NOT xManual;
    yDown := xAuto AND xPermit AND xDoor AND NOT xManual;
    yLock := xAuto AND xPermit AND xDoor;
    yAlarm := NOT xDoor;
END_FUNCTION_BLOCK
```
