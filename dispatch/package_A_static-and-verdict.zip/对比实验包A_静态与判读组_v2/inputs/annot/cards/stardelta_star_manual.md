# stardelta_star_manual

**变更单**：手动模式下允许星形输出，不再受手动闭锁限制；其余逻辑不变。

**周期数**：900 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_StarDelta
VAR_INPUT
    xStart    : BOOL;
    xStop     : BOOL;
    xOverload : BOOL;
    xReady    : BOOL;
    xManual   : BOOL;
END_VAR
VAR_OUTPUT
    yMain  : BOOL;
    yStar  : BOOL;
    yDelta : BOOL;
    yFault : BOOL;
END_VAR
VAR
    tonTrans : TON;
END_VAR
    yMain := xStart AND NOT xStop AND NOT xOverload AND NOT xReady;
    tonTrans(IN := yMain, PT := T#5S);
    yStar  := yMain AND NOT tonTrans.Q AND NOT xManual;
    yDelta := yMain AND tonTrans.Q;
    yFault := xOverload;
END_FUNCTION_BLOCK
```
