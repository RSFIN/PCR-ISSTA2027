# silo_low

**变更单**：料仓低料位加料阈值由 15 改为 20；其余逻辑不变。

**周期数**：300 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_Silo
VAR_INPUT
    rSilo : REAL;
END_VAR
VAR_OUTPUT
    yInlet  : BOOL;
    yOutlet : BOOL;
    yFull   : BOOL;
END_VAR
    IF rSilo < 15 THEN
        yInlet  := TRUE;
        yOutlet := FALSE;
        yFull   := FALSE;
    ELSIF rSilo > 85 THEN
        yInlet  := FALSE;
        yOutlet := TRUE;
    ELSE
        yOutlet := FALSE;
    END_IF;
END_FUNCTION_BLOCK
```
