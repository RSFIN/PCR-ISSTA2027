# indexer_ready_2500ms

**变更单**：xPart 上升沿后，索引就绪延时由 1 秒改为 2500 毫秒；其余逻辑不变。

**周期数**：600 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_Indexer
VAR_INPUT
    xPart : BOOL;
END_VAR
VAR_OUTPUT
    yIndex : BOOL;
    yReady : BOOL;
END_VAR
VAR
    rtPart  : R_TRIG;
    tonReady : TON;
END_VAR
    rtPart(CLK := xPart);
    IF rtPart.Q THEN
        yIndex := NOT yIndex;
    END_IF;
    tonReady(IN := yIndex, PT := T#1S);
    yReady := tonReady.Q;
END_FUNCTION_BLOCK
```
