# heat_on

**变更单**：温度回差控制的加热接通阈值由 45 改为 50；其余逻辑不变。

**周期数**：300 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_HeatBand
VAR_INPUT
    rTemp : REAL;
END_VAR
VAR_OUTPUT
    yHeat  : BOOL;
    yAlarm : BOOL;
END_VAR
    IF rTemp < 45 THEN
        yHeat  := TRUE;
        yAlarm := FALSE;
    ELSIF rTemp > 60 THEN
        yHeat  := FALSE;
        yAlarm := TRUE;
    ELSE
        yHeat  := FALSE;
        yAlarm := FALSE;
    END_IF;
END_FUNCTION_BLOCK
```
