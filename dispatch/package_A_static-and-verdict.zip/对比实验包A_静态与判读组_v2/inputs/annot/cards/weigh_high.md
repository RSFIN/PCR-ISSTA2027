# weigh_high

**变更单**：称重分选的超重阈值由 60 改为 50；其余逻辑不变。

**周期数**：300 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_WeighSort
VAR_INPUT
    iWeight : INT;
    xFeed   : BOOL;
END_VAR
VAR_OUTPUT
    ySort   : BOOL;
    yReject : BOOL;
    yReady  : BOOL;
END_VAR
    yReady := xFeed;
    IF iWeight < 30 THEN
        ySort   := FALSE;
        yReject := TRUE;
    ELSIF iWeight > 60 THEN
        ySort   := FALSE;
        yReject := TRUE;
    ELSE
        ySort   := TRUE;
        yReject := FALSE;
    END_IF;
END_FUNCTION_BLOCK
```
