# tonof_on_1000ms

**变更单**：xIn 上升沿触发的 TONOF 接通延时由 500 毫秒改为 1000 毫秒；其余逻辑不变。

**周期数**：700 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_TonOf
VAR_INPUT
    xIn : BOOL;
END_VAR
VAR_OUTPUT
    yQ : BOOL;
END_VAR
VAR
    tonOn  : TON;
    tonOff : TON;
    xHold  : BOOL;
END_VAR
    tonOn(IN := xIn AND NOT xHold, PT := T#500MS);
    IF tonOn.Q THEN
        xHold := TRUE;
    END_IF;
    tonOff(IN := NOT xIn AND xHold, PT := T#300MS);
    IF tonOff.Q THEN
        xHold := FALSE;
    END_IF;
    yQ := xHold;
END_FUNCTION_BLOCK
```
