# conveyor_perm_elim

**变更单**：消去中间变量 xPerm，把运行许可条件直接写进运行输出，行为必须逐周期不变；其余逻辑不变。

**周期数**：900 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_Conveyor
VAR_INPUT
    xStart    : BOOL;
    xStop     : BOOL;
    xEStop    : BOOL;
    xOverload : BOOL;
END_VAR
VAR_OUTPUT
    yRun   : BOOL;
    yFault : BOOL;
END_VAR
VAR
    tonDb : TON;
    xPerm : BOOL;
END_VAR
    tonDb(IN := xStart AND NOT xStop, PT := T#200MS);
    xPerm := tonDb.Q AND NOT xEStop AND NOT xOverload;
    yRun  := xPerm;
    yFault := xOverload OR xEStop;
END_FUNCTION_BLOCK
```
