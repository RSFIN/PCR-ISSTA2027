# guard_convey_last_manual

**变更单**：xStop 为 TRUE时，该联锁不再约束手动支路，手动模式下允许末段输送点动；xStop 为 TRUE这一前提不变，窗口外维持原闭锁；其余逻辑不变。

**周期数**：700 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_ConveyThree
VAR_INPUT
    xAuto      : BOOL;
    xManual    : BOOL;
    xStop      : BOOL;
    xPermit    : BOOL;
END_VAR
VAR_OUTPUT
    yConv1    : BOOL;
    yConv2    : BOOL;
    yConv3    : BOOL;
    yAlarm    : BOOL;
END_VAR
    yConv1 := xAuto AND xPermit AND NOT xStop AND NOT xManual;
    yConv2 := xAuto AND xPermit AND NOT xStop AND NOT xManual;
    yConv3 := xAuto AND xPermit AND NOT xStop;
    yAlarm := xStop;
END_FUNCTION_BLOCK
```
