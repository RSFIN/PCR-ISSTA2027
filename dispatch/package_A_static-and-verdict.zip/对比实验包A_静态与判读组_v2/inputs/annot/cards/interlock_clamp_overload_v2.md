# interlock_clamp_overload_v2

**变更单**：xOverload 置位时，过载联锁不再阻止夹紧输出，自动支路允许在过载工况下夹紧；xOverload 置位这一前提不变，窗口外维持原闭锁；手动支路的原逻辑不变；其余逻辑不变。

**周期数**：700 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_InterlockMatrix
VAR_INPUT
    xAuto     : BOOL;
    xManual   : BOOL;
    xReady    : BOOL;
    xOverload : BOOL;
END_VAR
VAR_OUTPUT
    yClamp : BOOL;
    yPress : BOOL;
    yEject : BOOL;
    yAlarm : BOOL;
END_VAR
    yClamp := xAuto AND xReady AND NOT xOverload AND NOT xManual;
    yPress := xAuto AND xReady AND NOT xOverload AND NOT xManual;
    yEject := xAuto AND xReady;
    yAlarm := NOT xOverload;
END_FUNCTION_BLOCK
```
