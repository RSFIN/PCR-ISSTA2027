# edge_arm_60ms

**变更单**：xA 上升沿后（xB 为 TRUE 时），互锁动作延时由 30 毫秒改为 60 毫秒；其余逻辑不变。

**周期数**：100 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_Edge
VAR_INPUT
    xA : BOOL;
    xB : BOOL;
END_VAR
VAR_OUTPUT
    yCmd : BOOL;
END_VAR
VAR
    tonArm : TON;
    xArm   : BOOL;
END_VAR
    tonArm(IN := xA, PT := T#30MS);
    xArm := tonArm.Q;
    yCmd := xArm AND xB;
END_FUNCTION_BLOCK
```
