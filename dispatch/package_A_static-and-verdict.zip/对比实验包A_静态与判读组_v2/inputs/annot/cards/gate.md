# gate

**变更单**：开门保持时间由 500 毫秒改为 800 毫秒；其余逻辑不变。

**周期数**：900 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_Gate
VAR_INPUT
    xPart : BOOL;
END_VAR
VAR_OUTPUT
    yGate : BOOL;
END_VAR
VAR
    rtPart  : R_TRIG;
    tonHold : TON;
END_VAR
    rtPart(CLK := xPart);
    IF rtPart.Q THEN
        yGate := TRUE;
    END_IF;
    tonHold(IN := yGate, PT := T#500MS);
    IF tonHold.Q THEN
        yGate := FALSE;
    END_IF;
END_FUNCTION_BLOCK
```
