# fan_purge_6s

**变更单**：xFan 断开沿后，排风挡板保持延时由 3 秒改为 6 秒；其余逻辑不变。

**周期数**：1000 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_FanPurge
VAR_INPUT
    xFan : BOOL;
END_VAR
VAR_OUTPUT
    yFan : BOOL;
    yDamper : BOOL;
END_VAR
VAR
    tofPurge : TOF;
END_VAR
    yFan := xFan;
    tofPurge(IN := xFan, PT := T#3S);
    yDamper := tofPurge.Q;
END_FUNCTION_BLOCK
```
