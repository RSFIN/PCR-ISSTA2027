# edge_arm_elim

**变更单**：消去中间变量 xArm，把延时到达判断直接写进输出，行为必须逐周期不变；其余逻辑不变。

**周期数**：100 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_Edge
VAR_INPUT
    xA : BOOL;
    xB : BOOL;
END_VAR
VAR_OUTPUT
    yCmd : BOOL;
END_VAR
VAR
    tonArm : TON;
    xArm   : BOOL;
END_VAR
    tonArm(IN := xA, PT := T#30MS);
    xArm := tonArm.Q;
    yCmd := xArm AND xB;
END_FUNCTION_BLOCK
```
