# press_low

**变更单**：压力低压报警阈值由 25 改为 35；其余逻辑不变。

**周期数**：300 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_PressAlarm
VAR_INPUT
    rPress  : REAL;
    xEnable : BOOL;
END_VAR
VAR_OUTPUT
    yLoAlarm : BOOL;
    yHiAlarm : BOOL;
    yPump    : BOOL;
END_VAR
    yLoAlarm := rPress < 25;
    yHiAlarm := rPress > 75;
    yPump    := xEnable AND NOT yLoAlarm AND NOT yHiAlarm;
END_FUNCTION_BLOCK
```
