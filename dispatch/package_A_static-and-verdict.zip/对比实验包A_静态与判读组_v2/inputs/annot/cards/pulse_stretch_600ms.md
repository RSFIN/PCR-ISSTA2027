# pulse_stretch_600ms

**变更单**：xTrig 上升沿触发的脉冲展宽时间由 300 毫秒改为 600 毫秒；其余逻辑不变。

**周期数**：700 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_PulseStretch
VAR_INPUT
    xTrig  : BOOL;
    xInh   : BOOL;
END_VAR
VAR_OUTPUT
    yPulse : BOOL;
    yBusy  : BOOL;
    yFault : BOOL;
END_VAR
VAR
    rtTrig   : R_TRIG;
    tonPulse : TON;
END_VAR
    rtTrig(CLK := xTrig);
    IF rtTrig.Q THEN
        yPulse := TRUE;
    END_IF;
    tonPulse(IN := yPulse, PT := T#300MS);
    IF tonPulse.Q THEN
        yPulse := FALSE;
    END_IF;
    yBusy  := yPulse AND NOT xInh;
    yFault := xInh AND NOT yPulse;
END_FUNCTION_BLOCK
```
