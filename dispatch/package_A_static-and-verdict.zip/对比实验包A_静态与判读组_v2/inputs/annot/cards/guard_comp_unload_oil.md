# guard_comp_unload_oil

**变更单**：xOil 断开时，该联锁不再约束手动支路，手动模式下允许卸载阀动作；xOil 断开这一前提不变，窗口外维持原闭锁；其余逻辑不变。

**周期数**：700 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_Compressor
VAR_INPUT
    xAuto      : BOOL;
    xManual    : BOOL;
    xOil       : BOOL;
    xPress     : BOOL;
END_VAR
VAR_OUTPUT
    yLoad      : BOOL;
    yBlow      : BOOL;
    yUnload    : BOOL;
    yAlarm     : BOOL;
END_VAR
    yLoad := xAuto AND xPress AND xOil AND NOT xManual;
    yBlow := xAuto AND xPress AND xOil AND NOT xManual;
    yUnload := xAuto AND xPress AND xOil;
    yAlarm := NOT xOil;
END_FUNCTION_BLOCK
```
