# guard_pack_index_film

**变更单**：xFilm 断开时，该联锁不再约束手动支路，手动模式下允许分度盘动作；xFilm 断开这一前提不变，窗口外维持原闭锁；其余逻辑不变。

**周期数**：700 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_PackIndex
VAR_INPUT
    xAuto      : BOOL;
    xManual    : BOOL;
    xFilm      : BOOL;
    xPermit    : BOOL;
END_VAR
VAR_OUTPUT
    ySeal     : BOOL;
    yCut      : BOOL;
    yIndex    : BOOL;
    yAlarm    : BOOL;
END_VAR
    ySeal := xAuto AND xPermit AND xFilm AND NOT xManual;
    yCut := xAuto AND xPermit AND xFilm AND NOT xManual;
    yIndex := xAuto AND xPermit AND xFilm;
    yAlarm := NOT xFilm;
END_FUNCTION_BLOCK
```
