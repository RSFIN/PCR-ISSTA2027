# guard_feeder_level_low

**变更单**：xLevel 断开时，该联锁不再约束手动支路，手动模式下允许给料机点动；xLevel 断开这一前提不变，窗口外维持原闭锁；其余逻辑不变。

**周期数**：700 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_FeedLine
VAR_INPUT
    xAuto      : BOOL;
    xManual    : BOOL;
    xLevel     : BOOL;
    xPermit    : BOOL;
END_VAR
VAR_OUTPUT
    yConvey    : BOOL;
    yMix       : BOOL;
    yFeeder    : BOOL;
    yAlarm     : BOOL;
END_VAR
    yConvey := xAuto AND xPermit AND xLevel AND NOT xManual;
    yMix := xAuto AND xPermit AND xLevel AND NOT xManual;
    yFeeder := xAuto AND xPermit AND xLevel;
    yAlarm := NOT xLevel;
END_FUNCTION_BLOCK
```
