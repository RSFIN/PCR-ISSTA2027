# flow_low

**变更单**：流量低限报警阈值由 40 改为 50；其余逻辑不变。

**周期数**：300 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_FlowAlarm
VAR_INPUT
    rFlow   : REAL;
    xPumpOn : BOOL;
END_VAR
VAR_OUTPUT
    yLowFlow : BOOL;
    yTrip    : BOOL;
END_VAR
    yLowFlow := rFlow < 40;
    IF xPumpOn AND yLowFlow THEN
        yTrip := TRUE;
    ELSE
        yTrip := FALSE;
    END_IF;
END_FUNCTION_BLOCK
```
