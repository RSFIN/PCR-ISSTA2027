# guard_press_retract_door

**变更单**：xGuard 断开时，该联锁不再约束手动支路，手动模式下允许压头回程；xGuard 断开这一前提不变，窗口外维持原闭锁；其余逻辑不变。

**周期数**：700 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_PressStation
VAR_INPUT
    xAuto      : BOOL;
    xManual    : BOOL;
    xGuard     : BOOL;
    xOil       : BOOL;
END_VAR
VAR_OUTPUT
    yClamp      : BOOL;
    yPress      : BOOL;
    yRetract    : BOOL;
    yAlarm      : BOOL;
END_VAR
    yClamp := xAuto AND xGuard AND xOil AND NOT xManual;
    yPress := xAuto AND xGuard AND xOil AND NOT xManual;
    yRetract := xAuto AND xGuard AND xOil;
    yAlarm := NOT xGuard;
END_FUNCTION_BLOCK
```
