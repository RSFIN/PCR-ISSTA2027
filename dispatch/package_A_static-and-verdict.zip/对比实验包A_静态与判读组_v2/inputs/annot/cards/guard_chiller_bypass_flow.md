# guard_chiller_bypass_flow

**变更单**：xFlow 断开时，该联锁不再约束手动支路，手动模式下允许旁通阀打开；xFlow 断开这一前提不变，窗口外维持原闭锁；其余逻辑不变。

**周期数**：700 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_ChillerLoop
VAR_INPUT
    xAuto      : BOOL;
    xManual    : BOOL;
    xFlow      : BOOL;
    xTemp      : BOOL;
END_VAR
VAR_OUTPUT
    yChW       : BOOL;
    yCwPump    : BOOL;
    yBypass    : BOOL;
    yAlarm     : BOOL;
END_VAR
    yChW := xAuto AND xTemp AND xFlow AND NOT xManual;
    yCwPump := xAuto AND xTemp AND xFlow AND NOT xManual;
    yBypass := xAuto AND xTemp AND xFlow;
    yAlarm := NOT xFlow;
END_FUNCTION_BLOCK
```
