# edge

**变更单**：互锁后的动作延时由 30ms 改为 50ms；其余逻辑不变。

**周期数**：20 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_Edge
VAR_INPUT
    xA : BOOL;
    xB : BOOL;
END_VAR
VAR_OUTPUT
    yCmd : BOOL;
END_VAR
VAR
    tonArm : TON;
    xArm   : BOOL;
END_VAR
    tonArm(IN := xA, PT := T#30MS);
    xArm := tonArm.Q;
    yCmd := xArm AND xB;
END_FUNCTION_BLOCK
```
