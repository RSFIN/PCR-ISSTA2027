# maint_lamp_manual

**变更单**：手动模式下允许运行指示输出，不再受手动闭锁限制；其余逻辑不变。

**周期数**：700 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_MaintBypass
VAR_INPUT
    xStart    : BOOL;
    xLevelLow : BOOL;
    xManual   : BOOL;
END_VAR
VAR_OUTPUT
    yPump  : BOOL;
    yAlarm : BOOL;
    yLamp  : BOOL;
END_VAR
    yPump  := xStart AND NOT xLevelLow;
    yAlarm := xLevelLow AND NOT xManual;
    yLamp  := xStart AND NOT xManual;
END_FUNCTION_BLOCK
```
