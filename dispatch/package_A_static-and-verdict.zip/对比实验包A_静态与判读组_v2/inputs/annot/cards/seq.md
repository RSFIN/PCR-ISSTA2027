# seq

**变更单**：把上升沿检测改为等价写法（删除未用变量、调整赋值顺序），行为必须逐周期不变。

**周期数**：20 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_Seq
VAR_INPUT
    xIn : BOOL;
END_VAR
VAR_OUTPUT
    ySeq : BOOL;
END_VAR
VAR
    r1 : BOOL;
    r2 : BOOL;
END_VAR
    r2 := r1;
    r1 := xIn;
    ySeq := r1 AND NOT r2;
END_FUNCTION_BLOCK
```
