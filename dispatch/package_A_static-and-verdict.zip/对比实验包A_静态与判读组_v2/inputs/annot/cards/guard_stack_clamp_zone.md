# guard_stack_clamp_zone

**变更单**：xZone 断开时，该联锁不再约束手动支路，手动模式下允许夹爪闭合；xZone 断开这一前提不变，窗口外维持原闭锁；其余逻辑不变。

**周期数**：700 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_Stacker
VAR_INPUT
    xAuto      : BOOL;
    xManual    : BOOL;
    xZone      : BOOL;
    xPermit    : BOOL;
END_VAR
VAR_OUTPUT
    yLift     : BOOL;
    yPush     : BOOL;
    yClamp    : BOOL;
    yAlarm    : BOOL;
END_VAR
    yLift := xAuto AND xPermit AND xZone AND NOT xManual;
    yPush := xAuto AND xPermit AND xZone AND NOT xManual;
    yClamp := xAuto AND xPermit AND xZone;
    yAlarm := NOT xZone;
END_FUNCTION_BLOCK
```
