# stardelta_ready_bypass

**变更单**：启动信号有效时不再等待就绪信号，过载保护保持不变；其余逻辑不变。

**周期数**：900 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_StarDelta
VAR_INPUT
    xStart    : BOOL;
    xStop     : BOOL;
    xOverload : BOOL;
    xReady    : BOOL;
END_VAR
VAR_OUTPUT
    yMain  : BOOL;
    yStar  : BOOL;
    yDelta : BOOL;
    yFault : BOOL;
END_VAR
VAR
    tonTrans : TON;
END_VAR
    yMain := xStart AND NOT xStop AND NOT xOverload AND NOT xReady;
    tonTrans(IN := yMain, PT := T#5S);
    yStar  := yMain AND NOT tonTrans.Q;
    yDelta := yMain AND tonTrans.Q;
    yFault := xOverload;
END_FUNCTION_BLOCK
```
