# guard_sorter_gate_jam

**变更单**：xJam 为 TRUE时，该联锁不再约束手动支路，手动模式下允许闸门开合；xJam 为 TRUE这一前提不变，窗口外维持原闭锁；其余逻辑不变。

**周期数**：700 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_SorterGate
VAR_INPUT
    xAuto      : BOOL;
    xManual    : BOOL;
    xJam       : BOOL;
    xPermit    : BOOL;
END_VAR
VAR_OUTPUT
    yMain        : BOOL;
    yDiverter    : BOOL;
    yGate        : BOOL;
    yAlarm       : BOOL;
END_VAR
    yMain := xAuto AND xPermit AND NOT xJam AND NOT xManual;
    yDiverter := xAuto AND xPermit AND NOT xJam AND NOT xManual;
    yGate := xAuto AND xPermit AND NOT xJam;
    yAlarm := xJam;
END_FUNCTION_BLOCK
```
