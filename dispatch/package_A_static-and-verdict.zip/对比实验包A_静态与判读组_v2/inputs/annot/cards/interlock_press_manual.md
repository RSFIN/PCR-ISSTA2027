# interlock_press_manual

**变更单**：手动模式下允许压合动作，不再受手动闭锁限制；其余逻辑不变。

**周期数**：700 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_InterlockMatrix
VAR_INPUT
    xAuto     : BOOL;
    xManual   : BOOL;
    xReady    : BOOL;
    xOverload : BOOL;
END_VAR
VAR_OUTPUT
    yClamp : BOOL;
    yPress : BOOL;
    yEject : BOOL;
    yAlarm : BOOL;
END_VAR
    yClamp := xAuto AND xReady AND NOT xOverload AND NOT xManual;
    yPress := xAuto AND xReady AND NOT xOverload AND NOT xManual;
    yEject := xAuto AND xReady;
    yAlarm := NOT xOverload;
END_FUNCTION_BLOCK
```
