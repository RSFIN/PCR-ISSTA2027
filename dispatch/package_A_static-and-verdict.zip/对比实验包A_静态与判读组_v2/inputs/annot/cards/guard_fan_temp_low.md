# guard_fan_temp_low

**变更单**：xTemp 断开时，该联锁不再约束手动支路，允许循环风机单独运行；xTemp 断开这一前提不变，窗口外维持原闭锁；其余逻辑不变。

**周期数**：700 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_OvenAir
VAR_INPUT
    xAuto      : BOOL;
    xManual    : BOOL;
    xTemp      : BOOL;
    xPermit    : BOOL;
END_VAR
VAR_OUTPUT
    yHeat      : BOOL;
    yDamper    : BOOL;
    yFan       : BOOL;
    yAlarm     : BOOL;
END_VAR
    yHeat := xAuto AND xPermit AND xTemp AND NOT xManual;
    yDamper := xAuto AND xPermit AND xTemp AND NOT xManual;
    yFan := xAuto AND xPermit AND xTemp;
    yAlarm := NOT xTemp;
END_FUNCTION_BLOCK
```
