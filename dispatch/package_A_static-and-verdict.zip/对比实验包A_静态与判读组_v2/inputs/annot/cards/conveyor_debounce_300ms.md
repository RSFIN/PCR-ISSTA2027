# conveyor_debounce_300ms

**变更单**：xStart 上升沿后，传送带启动确认延时由 200 毫秒改为 300 毫秒；其余逻辑不变。

**周期数**：400 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_ConveyorStartConfirm
VAR_INPUT
    xStart : BOOL;
END_VAR
VAR_OUTPUT
    yReady : BOOL;
END_VAR
VAR
    tonConfirm : TON;
END_VAR
    tonConfirm(IN := xStart, PT := T#200MS);
    yReady := tonConfirm.Q;
END_FUNCTION_BLOCK
```
