# guard_pump_c_fault

**变更单**：xFault 为 TRUE时，该联锁不再约束手动支路，手动模式下允许 C 泵运行；xFault 为 TRUE这一前提不变，窗口外维持原闭锁；其余逻辑不变。

**周期数**：700 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_PumpTrio
VAR_INPUT
    xAuto      : BOOL;
    xManual    : BOOL;
    xFault     : BOOL;
    xLevel     : BOOL;
END_VAR
VAR_OUTPUT
    yPumpA    : BOOL;
    yPumpB    : BOOL;
    yPumpC    : BOOL;
    yAlarm    : BOOL;
END_VAR
    yPumpA := xAuto AND xLevel AND NOT xFault AND NOT xManual;
    yPumpB := xAuto AND xLevel AND NOT xFault AND NOT xManual;
    yPumpC := xAuto AND xLevel AND NOT xFault;
    yAlarm := xFault;
END_FUNCTION_BLOCK
```
