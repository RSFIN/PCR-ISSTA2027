# guard_mixer_dis_cover

**变更单**：xCover 断开时，该联锁不再约束手动支路，手动模式下允许出料阀打开；xCover 断开这一前提不变，窗口外维持原闭锁；其余逻辑不变。

**周期数**：700 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_MixerTank
VAR_INPUT
    xAuto      : BOOL;
    xManual    : BOOL;
    xCover     : BOOL;
    xPermit    : BOOL;
END_VAR
VAR_OUTPUT
    yFeed         : BOOL;
    yAgitate      : BOOL;
    yDischarge    : BOOL;
    yAlarm        : BOOL;
END_VAR
    yFeed := xAuto AND xPermit AND xCover AND NOT xManual;
    yAgitate := xAuto AND xPermit AND xCover AND NOT xManual;
    yDischarge := xAuto AND xPermit AND xCover;
    yAlarm := NOT xCover;
END_FUNCTION_BLOCK
```
