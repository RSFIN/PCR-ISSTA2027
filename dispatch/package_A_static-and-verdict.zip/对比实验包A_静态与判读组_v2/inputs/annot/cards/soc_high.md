# soc_high

**变更单**：电池组过压保护阈值由 80 改为 70；其余逻辑不变。

**周期数**：300 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_SocGuard
VAR_INPUT
    rSoc : REAL;
END_VAR
VAR_OUTPUT
    yCharge    : BOOL;
    yDischarge : BOOL;
    yWarn      : BOOL;
END_VAR
    IF rSoc < 20 THEN
        yCharge    := TRUE;
        yDischarge := FALSE;
        yWarn      := TRUE;
    ELSIF rSoc > 80 THEN
        yCharge    := FALSE;
        yDischarge := FALSE;
        yWarn      := TRUE;
    ELSE
        yCharge    := FALSE;
        yDischarge := TRUE;
        yWarn      := FALSE;
    END_IF;
END_FUNCTION_BLOCK
```
