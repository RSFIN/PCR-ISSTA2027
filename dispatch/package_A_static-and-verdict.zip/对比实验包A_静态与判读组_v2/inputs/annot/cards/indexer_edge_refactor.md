# indexer_edge_refactor

**变更单**：将 xPart 的 R_TRIG 边沿检测改为显式上升沿判断，行为必须逐周期不变；其余逻辑不变。

**周期数**：500 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_Indexer
VAR_INPUT
    xPart : BOOL;
END_VAR
VAR_OUTPUT
    yIndex : BOOL;
    yReady : BOOL;
END_VAR
VAR
    rtPart  : R_TRIG;
    tonReady : TON;
END_VAR
    rtPart(CLK := xPart);
    IF rtPart.Q THEN
        yIndex := NOT yIndex;
    END_IF;
    tonReady(IN := yIndex, PT := T#1S);
    yReady := tonReady.Q;
END_FUNCTION_BLOCK
```
