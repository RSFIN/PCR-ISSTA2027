# pump_fault_jog

**变更单**：手动模式下禁止故障闭锁生效，仍允许点动阀门；其余逻辑不变。

**周期数**：700 ｜ **扫描周期**：10 ms

**原程序**：

```st
FUNCTION_BLOCK FB_PumpStation
VAR_INPUT
    xAuto     : BOOL;
    xManual   : BOOL;
    xLevelLow : BOOL;
    xFault  : BOOL;
END_VAR
VAR_OUTPUT
    yValve : BOOL;
    yPump  : BOOL;
    yAlarm : BOOL;
END_VAR
VAR
    tonSoft : TON;
END_VAR
    yValve := (xAuto OR xManual) AND NOT xLevelLow AND NOT xFault;
    tonSoft(IN := yValve, PT := T#0S);
    yPump  := yValve AND tonSoft.Q;
    yAlarm := xLevelLow;
END_FUNCTION_BLOCK
```
