FUNCTION_BLOCK FB_StarDelta
VAR_INPUT
    xStart    : BOOL;
    xStop     : BOOL;
    xOverload : BOOL;
    xReady    : BOOL;
END_VAR
VAR_OUTPUT
    yMain  : BOOL;
    yStar  : BOOL;
    yDelta : BOOL;
    yFault : BOOL;
END_VAR
VAR
    tonTrans_c1 : TON;
END_VAR
    yMain := xStart AND NOT xStop AND NOT xOverload AND NOT xReady;
    tonTrans_c1(IN := yMain, PT := T#5S);
    yStar  := yMain AND NOT tonTrans_c1.Q;
    yDelta := yMain AND tonTrans_c1.Q;
    yFault := xOverload;
END_FUNCTION_BLOCK
