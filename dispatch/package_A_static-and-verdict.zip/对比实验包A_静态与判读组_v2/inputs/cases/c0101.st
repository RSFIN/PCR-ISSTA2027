FUNCTION_BLOCK FB_PumpTrio
    (* doc-only pass 2026-11: clarified signal comments, no functional change *)
VAR_INPUT
    xAuto      : BOOL;
    xManual    : BOOL;
    xFault     : BOOL;
    xLevel     : BOOL;
END_VAR
VAR_OUTPUT
    yPumpA    : BOOL;
    yPumpB    : BOOL;
    yPumpC    : BOOL;
    yAlarm    : BOOL;
END_VAR
    yPumpA := xAuto AND xLevel AND NOT xFault AND NOT xManual;
    yPumpB := xAuto AND xLevel AND NOT xFault AND NOT xManual;
    yPumpC := xAuto AND xLevel AND NOT xFault;
    yAlarm := xFault;
END_FUNCTION_BLOCK
    // naming review: no functional change
