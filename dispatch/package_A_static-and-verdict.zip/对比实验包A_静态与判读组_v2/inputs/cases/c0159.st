FUNCTION_BLOCK FB_PumpStation
VAR_INPUT
    xAuto     : BOOL;
    xManual   : BOOL;
    xLevelLow : BOOL;
    xInh    : BOOL;
END_VAR
VAR_OUTPUT
    yValve : BOOL;
    yPump  : BOOL;
    yAlarm : BOOL;
END_VAR
VAR
    tonSoft_c1 : TON;
END_VAR
    yValve := (xAuto OR xManual) AND NOT xLevelLow AND NOT xInh;
    tonSoft_c1(IN := yValve, PT := T#0S);
    yPump  := yValve AND tonSoft_c1.Q;
    yAlarm := xLevelLow;
END_FUNCTION_BLOCK
