FUNCTION_BLOCK FB_ConveyorStartConfirm
    (* doc-only pass 2026-11: clarified signal comments, no functional change *)
VAR_INPUT
    xStart : BOOL;
END_VAR
VAR_OUTPUT
    yReady : BOOL;
END_VAR
VAR
    tonConfirm : TON;
END_VAR
    tonConfirm(IN := xStart, PT := T#200MS);
    yReady := tonConfirm.Q;
END_FUNCTION_BLOCK
    // naming review: no functional change
