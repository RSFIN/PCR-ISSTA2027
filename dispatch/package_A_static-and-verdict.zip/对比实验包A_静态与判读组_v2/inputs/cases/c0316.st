FUNCTION_BLOCK FB_PumpStandby
    (* doc-only pass 2026-11: clarified signal comments, no functional change *)
VAR_INPUT
    xAuto   : BOOL;
    xManual : BOOL;
    xFault  : BOOL;
END_VAR
VAR_OUTPUT
    yPumpA     : BOOL;
    yPumpB     : BOOL;
    ySwapAlarm : BOOL;
    yLamp      : BOOL;
END_VAR
    yPumpA     := xAuto AND NOT xFault AND NOT xManual;
    yPumpB     := xAuto AND xFault;
    ySwapAlarm := xFault AND NOT xManual;
    yLamp      := xAuto;
END_FUNCTION_BLOCK
    // naming review: no functional change
