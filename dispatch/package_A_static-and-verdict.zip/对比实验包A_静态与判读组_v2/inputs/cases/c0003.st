FUNCTION_BLOCK FB_PulseStretch
    (* doc-only pass 2026-11: clarified signal comments, no functional change *)
VAR_INPUT
    xTrig  : BOOL;
    xInh   : BOOL;
END_VAR
VAR_OUTPUT
    yPulse : BOOL;
    yBusy  : BOOL;
    yFault : BOOL;
END_VAR
VAR
    rtTrig   : R_TRIG;
    tonPulse : TON;
END_VAR
    rtTrig(CLK := xTrig);
    IF rtTrig.Q THEN
        yPulse := TRUE;
    END_IF;
    tonPulse(IN := yPulse, PT := T#300MS);
    IF tonPulse.Q THEN
        yPulse := FALSE;
    END_IF;
    yBusy  := yPulse AND NOT xInh;
    yFault := xInh AND NOT yPulse;
END_FUNCTION_BLOCK
    // naming review: no functional change
