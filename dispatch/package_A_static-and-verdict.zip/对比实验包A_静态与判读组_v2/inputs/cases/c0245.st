FUNCTION_BLOCK FB_StarDelta
    (* doc-only pass 2026-11: clarified signal comments, no functional change *)
VAR_INPUT
    xStart    : BOOL;
    xStop     : BOOL;
    xOverload : BOOL;
END_VAR
VAR_OUTPUT
    yMain  : BOOL;
    yStar  : BOOL;
    yDelta : BOOL;
    yFault : BOOL;
END_VAR
VAR
    tonTrans_c1 : TON;
END_VAR
    yMain := xStart AND NOT xStop AND NOT xOverload;
    tonTrans_c1(IN := yMain, PT := T#5S);
    yStar  := yMain AND NOT tonTrans_c1.Q;
    yDelta := yMain AND tonTrans_c1.Q;
    yFault := xOverload;
END_FUNCTION_BLOCK
    // naming review: no functional change
