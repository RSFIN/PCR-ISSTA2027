FUNCTION_BLOCK FB_StarDelta
    (* doc-only pass 2026-11: clarified signal comments, no functional change *)
VAR_INPUT
    xStart    : BOOL;
    xStop     : BOOL;
    xOverload : BOOL;
    xReady    : BOOL;
    xManual   : BOOL;
END_VAR
VAR_OUTPUT
    yMain  : BOOL;
    yStar  : BOOL;
    yDelta : BOOL;
    yFault : BOOL;
END_VAR
VAR
    tonTrans : TON;
END_VAR
    yMain := xStart AND NOT xStop AND NOT xOverload AND NOT xReady;
    tonTrans(IN := yMain, PT := T#5S);
    yStar  := yMain AND NOT tonTrans.Q AND NOT xManual;
    yDelta := yMain AND tonTrans.Q;
    yFault := xOverload;
END_FUNCTION_BLOCK
    // naming review: no functional change
