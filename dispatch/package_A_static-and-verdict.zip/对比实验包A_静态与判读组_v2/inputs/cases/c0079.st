FUNCTION_BLOCK FB_Tank
    (* doc-only pass 2026-11: clarified signal comments, no functional change *)
VAR_INPUT
    iLevel : INT;
    xReset : BOOL;
END_VAR
VAR_OUTPUT
    yPump  : BOOL;
    yAlarm : BOOL;
END_VAR
    IF iLevel <= 10 THEN
        yPump  := FALSE;
        yAlarm := TRUE;
    ELSIF iLevel >= 90 THEN
        yPump  := FALSE;
        yAlarm := FALSE;
    ELSE
        yPump  := TRUE;
        yAlarm := FALSE;
    END_IF;
END_FUNCTION_BLOCK
    // naming review: no functional change
