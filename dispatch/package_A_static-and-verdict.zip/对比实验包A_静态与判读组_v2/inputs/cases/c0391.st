FUNCTION_BLOCK FB_Edge
    (* doc-only pass 2026-11: clarified signal comments, no functional change *)
VAR_INPUT
    xA : BOOL;
    xB : BOOL;
END_VAR
VAR_OUTPUT
    yCmd : BOOL;
END_VAR
VAR
    tonArm : TON;
    xArm   : BOOL;
END_VAR
    tonArm(IN := xA, PT := T#30MS);
    xArm := tonArm.Q;
    yCmd := xArm AND xB;
END_FUNCTION_BLOCK
    // naming review: no functional change
