FUNCTION_BLOCK FB_FlowAlarm
    (* doc-only pass 2026-11: clarified signal comments, no functional change *)
VAR_INPUT
    rFlow   : REAL;
    xPumpOn : BOOL;
END_VAR
VAR_OUTPUT
    yLowFlow : BOOL;
    yTrip    : BOOL;
END_VAR
    yLowFlow := rFlow < 40;
    IF xPumpOn AND yLowFlow THEN
        yTrip := TRUE;
    ELSE
        yTrip := FALSE;
    END_IF;
END_FUNCTION_BLOCK
    // naming review: no functional change
