FUNCTION_BLOCK FB_PumpStation
    (* doc-only pass 2026-11: clarified signal comments, no functional change *)
VAR_INPUT
    xAuto     : BOOL;
    xManual   : BOOL;
    xLevelLow : BOOL;
END_VAR
VAR_OUTPUT
    yValve : BOOL;
    yPump  : BOOL;
    yAlarm : BOOL;
END_VAR
VAR
    tonSoft : TON;
END_VAR
    yValve := (xAuto OR xManual) AND NOT xLevelLow;
    tonSoft(IN := yValve, PT := T#0S);
    yPump  := yValve AND tonSoft.Q;
    yAlarm := xLevelLow;
END_FUNCTION_BLOCK
    // naming review: no functional change
