FUNCTION_BLOCK FB_HeatZone
    (* doc-only pass 2026-11: clarified signal comments, no functional change *)
VAR_INPUT
    xAuto   : BOOL;
    xManual : BOOL;
    iTemp   : INT;
END_VAR
VAR_OUTPUT
    yHeat1    : BOOL;
    yHeat2    : BOOL;
    yOverTemp : BOOL;
END_VAR
    yHeat1    := xAuto AND NOT xManual;
    yHeat2    := xAuto;
    yOverTemp := iTemp >= 80 AND NOT xManual;
END_FUNCTION_BLOCK
    // naming review: no functional change
