FUNCTION_BLOCK FB_HeatBand
    (* doc-only pass 2026-11: clarified signal comments, no functional change *)
VAR_INPUT
    rTemp : REAL;
END_VAR
VAR_OUTPUT
    yHeat  : BOOL;
    yAlarm : BOOL;
END_VAR
    IF rTemp < 45 THEN
        yHeat  := TRUE;
        yAlarm := FALSE;
    ELSIF rTemp > 60 THEN
        yHeat  := FALSE;
        yAlarm := TRUE;
    ELSE
        yHeat  := FALSE;
        yAlarm := FALSE;
    END_IF;
END_FUNCTION_BLOCK
    // naming review: no functional change
