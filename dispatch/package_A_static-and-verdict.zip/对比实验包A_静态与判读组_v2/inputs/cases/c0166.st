FUNCTION_BLOCK FB_ConveyorStartConfirm
VAR_INPUT
    xStart : BOOL;
END_VAR
VAR_OUTPUT
    yReady : BOOL;
END_VAR
VAR
    tonConfirm_c1 : TON;
END_VAR
    tonConfirm_c1(IN := xStart, PT := T#200MS);
    yReady := tonConfirm_c1.Q;
END_FUNCTION_BLOCK
