FUNCTION_BLOCK FB_SocGuard
    (* doc-only pass 2026-11: clarified signal comments, no functional change *)
VAR_INPUT
    rSoc : REAL;
END_VAR
VAR_OUTPUT
    yCharge    : BOOL;
    yDischarge : BOOL;
    yWarn      : BOOL;
END_VAR
    IF rSoc < 20 THEN
        yCharge    := TRUE;
        yDischarge := FALSE;
        yWarn      := TRUE;
    ELSIF rSoc > 80 THEN
        yCharge    := FALSE;
        yDischarge := FALSE;
        yWarn      := TRUE;
    ELSE
        yCharge    := FALSE;
        yDischarge := TRUE;
        yWarn      := FALSE;
    END_IF;
END_FUNCTION_BLOCK
    // naming review: no functional change
