FUNCTION_BLOCK FB_PressAlarm
    (* doc-only pass 2026-11: clarified signal comments, no functional change *)
VAR_INPUT
    rPress  : REAL;
    xEnable : BOOL;
END_VAR
VAR_OUTPUT
    yLoAlarm : BOOL;
    yHiAlarm : BOOL;
    yPump    : BOOL;
END_VAR
    yLoAlarm := rPress < 25;
    yHiAlarm := rPress > 75;
    yPump    := xEnable AND NOT yLoAlarm AND NOT yHiAlarm;
END_FUNCTION_BLOCK
    // naming review: no functional change
