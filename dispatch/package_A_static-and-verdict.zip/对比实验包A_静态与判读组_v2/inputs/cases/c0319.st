FUNCTION_BLOCK FB_PackIndex
    (* doc-only pass 2026-11: clarified signal comments, no functional change *)
VAR_INPUT
    xAuto      : BOOL;
    xManual    : BOOL;
    xFilm      : BOOL;
    xPermit    : BOOL;
END_VAR
VAR_OUTPUT
    ySeal     : BOOL;
    yCut      : BOOL;
    yIndex    : BOOL;
    yAlarm    : BOOL;
END_VAR
    ySeal := xAuto AND xPermit AND xFilm AND NOT xManual;
    yCut := xAuto AND xPermit AND xFilm AND NOT xManual;
    yIndex := xAuto AND xPermit AND xFilm;
    yAlarm := NOT xFilm;
END_FUNCTION_BLOCK
    // naming review: no functional change
