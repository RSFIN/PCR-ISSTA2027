FUNCTION_BLOCK FB_EnableChain
    (* doc-only pass 2026-11: clarified signal comments, no functional change *)
VAR_INPUT
    xStart  : BOOL;
    xAuto   : BOOL;
    xManual : BOOL;
END_VAR
VAR_OUTPUT
    yHeat : BOOL;
    yFan  : BOOL;
    yLamp : BOOL;
END_VAR
    yHeat := xStart AND NOT xManual;
    yFan  := xStart;
    yLamp := xStart AND NOT xManual AND NOT xAuto;
END_FUNCTION_BLOCK
    // naming review: no functional change
