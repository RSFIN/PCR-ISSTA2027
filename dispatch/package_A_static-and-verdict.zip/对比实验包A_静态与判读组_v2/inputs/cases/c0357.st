FUNCTION_BLOCK FB_FanPurge
    (* doc-only pass 2026-11: clarified signal comments, no functional change *)
VAR_INPUT
    xFan : BOOL;
END_VAR
VAR_OUTPUT
    yFan : BOOL;
    yDamper : BOOL;
END_VAR
VAR
    tofPurge_c1 : TOF;
END_VAR
    yFan := xFan;
    tofPurge_c1(IN := xFan, PT := T#3S);
    yDamper := tofPurge_c1.Q;
END_FUNCTION_BLOCK
    // naming review: no functional change
