FUNCTION_BLOCK FB_MixerTank
    (* doc-only pass 2026-11: clarified signal comments, no functional change *)
VAR_INPUT
    xAuto      : BOOL;
    xManual    : BOOL;
    xCover     : BOOL;
    xPermit    : BOOL;
END_VAR
VAR_OUTPUT
    yFeed         : BOOL;
    yAgitate      : BOOL;
    yDischarge    : BOOL;
    yAlarm        : BOOL;
END_VAR
    yFeed := xAuto AND xPermit AND xCover AND NOT xManual;
    yAgitate := xAuto AND xPermit AND xCover AND NOT xManual;
    yDischarge := xAuto AND xPermit AND xCover;
    yAlarm := NOT xCover;
END_FUNCTION_BLOCK
    // naming review: no functional change
