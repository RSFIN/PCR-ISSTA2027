FUNCTION_BLOCK FB_Indexer
    (* doc-only pass 2026-11: clarified signal comments, no functional change *)
VAR_INPUT
    xPart : BOOL;
END_VAR
VAR_OUTPUT
    yIndex : BOOL;
    yReady : BOOL;
END_VAR
VAR
    rtPart_c1  : R_TRIG;
    tonReady : TON;
END_VAR
    rtPart_c1(CLK := xPart);
    IF rtPart_c1.Q THEN
        yIndex := NOT yIndex;
    END_IF;
    tonReady(IN := yIndex, PT := T#1S);
    yReady := tonReady.Q;
END_FUNCTION_BLOCK
    // naming review: no functional change
