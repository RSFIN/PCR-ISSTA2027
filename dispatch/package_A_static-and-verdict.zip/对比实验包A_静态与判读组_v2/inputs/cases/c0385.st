FUNCTION_BLOCK FB_Seq
VAR_INPUT
    xIn : BOOL;
END_VAR
VAR_OUTPUT
    ySeq : BOOL;
END_VAR
VAR
    r1 : BOOL;
END_VAR
    ySeq := xIn AND NOT r1;
    r1 := xIn;
END_FUNCTION_BLOCK
