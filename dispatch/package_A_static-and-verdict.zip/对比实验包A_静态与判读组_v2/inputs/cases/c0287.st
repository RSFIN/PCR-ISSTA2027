FUNCTION_BLOCK FB_Gate
    (* doc-only pass 2026-11: clarified signal comments, no functional change *)
VAR_INPUT
    xPart : BOOL;
END_VAR
VAR_OUTPUT
    yGate : BOOL;
END_VAR
VAR
    rtPart_c1  : R_TRIG;
    tonHold : TON;
END_VAR
    rtPart_c1(CLK := xPart);
    IF rtPart_c1.Q THEN
        yGate := TRUE;
    END_IF;
    tonHold(IN := yGate, PT := T#500MS);
    IF tonHold.Q THEN
        yGate := FALSE;
    END_IF;
END_FUNCTION_BLOCK
    // naming review: no functional change
