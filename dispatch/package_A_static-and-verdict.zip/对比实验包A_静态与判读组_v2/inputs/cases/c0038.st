FUNCTION_BLOCK FB_Compressor
    (* doc-only pass 2026-11: clarified signal comments, no functional change *)
VAR_INPUT
    xAuto      : BOOL;
    xManual    : BOOL;
    xOil       : BOOL;
    xPress     : BOOL;
END_VAR
VAR_OUTPUT
    yLoad      : BOOL;
    yBlow      : BOOL;
    yUnload    : BOOL;
    yAlarm     : BOOL;
END_VAR
    yLoad := xAuto AND xPress AND xOil AND NOT xManual;
    yBlow := xAuto AND xPress AND xOil AND NOT xManual;
    yUnload := xAuto AND xPress AND xOil;
    yAlarm := NOT xOil;
END_FUNCTION_BLOCK
    // naming review: no functional change
